addappid(1623730)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1623731,0,"7a422988135296505205dd489945d4b17ed7414734dd627744adac84aade7b73")
setManifestid(1623731,"6412707961042625301")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]